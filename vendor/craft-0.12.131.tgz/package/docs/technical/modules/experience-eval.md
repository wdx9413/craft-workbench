# Experience / Eval Kernel

## 在产品架构中的位置

**评测与实验属于第三支柱“学习与改进”**，与记忆与知识、学习与适应、编译与复用并列。独立模块表示职责清晰，不表示第四支柱。第二支柱“执行与保障”的验证与观察负责本次工作的结果和运行状态；评测使用跨案例/版本证据判断方法是否值得复用。

## 通用评测范围（目标）

| 对象 | 关键问题 |
| --- | --- |
| 能力检索与上下文 | 是否找到所需工具/资料、引用正确版本，是否混入无关或无权限内容 |
| 记忆与偏好 | 是否减少重复解释，是否出现过期知识、跨项目混用和错误泛化 |
| Agent、模型与规划 | 任务完成质量、资源使用、分工、询问/停止时机和人工接管 |
| Workflow、脚本与 Harness | 稳定性、新输入适用性、质量/成本/时延和历史能力保持 |
| 整项交付 | 格式与可编辑性、来源、遗漏、用户接受程度及后续业务效果 |

这是完整目标范围。当前正式版本对比支持 Workflow、Agent Profile、Harness Configuration；其他对象的通用评测执行与真实行业数据仍待建设，不因注册了 Validator/Capability 就视为已覆盖。

程序检查用于可计算条件，模型量表需校准，人工可做成对偏好选择，延迟业务信号保留观察窗口与归因限制。研发覆盖率、视频审美、销售结果和教学反馈不能统一伪装成程序证明。

## 已实现对象

- Harness Configuration：版本化的 context、tools、generation、orchestration、memory、output 六维配置。
- Trial：不可变，绑定 Task、Case、Subject 精确版本和可选 Harness 精确版本。
- Trace：按 Trial 单调追加事件。
- Outcome：每个 Trial 只能记录一次，保存 verdict、scores、costs、Evidence 和来源。
- Evaluation Run：聚合同一 Suite 分区、同一 Subject 版本的已完成 Trial。
- Eval Runner：对确定性 Workflow 自动执行 `Case × Subject × N Trial`，再保存 Evaluation Run 与可比 Comparison；Agent Subject 由 Runtime/Host 形成真实 Trial 后才可录入。
- Evaluation Aggregate：从 Outcome 复算通过率、verdict、数值 score、cost、duration 和 failure type 分布，不依赖模型总结。
- Evaluation Comparison：只比较同一 Suite 精确版本、同一分区、同一 Subject 类型和相同 Case 集合，并保存两侧聚合快照与 delta。
- Workflow Trial Run：一次调用锁定 Workflow 精确版本，并自动登记 Trial、起止 Trace、执行回执 Artifact、程序 Evidence 和唯一 Outcome。确定性检查不通过与运行时崩溃都会形成可追踪的失败结果，崩溃详情默认脱敏。
- Orchestration Trial：创建时锁定 Plan 初始版本和所有 Agent Profile 路由版本；Dispatch、失败换路和 Submit 自动进入 Trace，终态自动登记回执、Evidence、节点统计、累计成本和 Outcome。
- Grader / Grade / Signoff：区分程序、模型、人工和业务来源，以显式 Grade 集合和版本化 Policy 生成可复算的晋级决定。
- Program Grader：0.9.6 可按通过率、平均时延等确定性规则对一个 Evaluation Run 的每个 Trial 生成 Grade；模型、人工和业务 Grader 仍要求兼容 Host 回填观察结果。
- Promotion Assessment：0.9.6/0.9.7 将 held-out 的 baseline/candidate Comparison 做配对 Case 对照，检查最少 Trial 数、通过率增量，以及分离的指定成本指标与 `duration_ms` 回归阈值，并持久化可复算的晋级建议。
- Evaluation Reliability：v0.9.9 对同 Case、同环境、等预算的重复配对 Trial 做单侧精确配对检验，明确返回 `eligible`、`rejected` 或 `inconclusive`；环境、预算或样本量不满足时不得晋级。模型/人工 Judge 必须先有金标一致性校准，未校准时只能提供诊断。
- Adaptation Candidate：成功/失败证据可形成最多两个 Harness 设计轴差异的 `draft`；它必须经过可靠性评估和候选 Run 的 exact passed Signoff 才能进入 Canary。Canary 指标回归会保存精确 rollback 目标，候选从不直接改写 Skill、Workflow 或默认拓扑。
- Experience Pattern：至少引用两个已完成 Trial 与 Evidence，保存成功策略、失败模式、适用条件和从 Outcome 派生的结果摘要；不复制 Trace。0.9.8 的 Experience Miner 从重复的成功策略和失败模式生成 `proposal_only` 候选，仅保留事件类型和 Evidence 引用，不自动创建或发布 Skill。
- Shadow Experiment：0.9.8 只能将 `proposal_only` 候选送入只读 Workflow 的 held-out baseline/candidate 对照；它保存 Runner、Comparison、Promotion 和精确 Signoff Policy 的准备态。Promotion 通过仅为 `signoff_ready`，不产生 Signoff、更不允许发布。
- Skill Proposal / Publication：版本化的 `SKILL.md` 候选复用 Evaluation/Signoff Gate；仅在明确授权、Source 内路径校验、摘要校验与备份完成后发布，回滚同样受摘要保护。

## 关键门禁

Evaluation Suite 的 Case 显式属于 `search`、`development` 或 `held_out`。Workflow 或 Skill Proposal 从 `candidate` 晋级 `verified` 时，必须引用该精确版本且全部通过的 held-out Evaluation Run 或对应的 passed Signoff。

若 Workflow 使用 Evaluation Run 的直接晋级入口，v0.9.7 还必须引用同一 Candidate Run 的 `eligible` Promotion Assessment；缺少成本或时延指标而又配置相应阈值时，Gate 失败而不是把缺失数据视为通过。v0.9.8 的 Shadow 只为指定 Policy 准备独立 Grade/Signoff 输入，Signoff 仍是需要模型/人工/业务 Grade 的精确门禁。

Workflow、Agent Profile 和 Harness Configuration 都可以作为被测 Subject，但不同 Subject 类型不能直接比较。质量和 score 越高越好，cost 与 duration 越低越好；指标方向冲突时结果为 `mixed`，而不是强行给出赢家。除 v0.9.9 的成对可靠性检验外，其余聚合仍是确定性描述统计；内置脱敏 fixture 只证明机制，不证明真实业务质量。

## 边界与下一步

Lease TTL/续租与中断恢复、默认路线的 Trial/Trace/Outcome 归档已实现。Runtime Core 增加了审批等待、父子 Operation 账本、环境/Policy 指纹和预算暂停；Operational Signal 可产生窗口化漂移告警。v0.9.9 的线上反馈入口只接收脱敏摘要/指标引用，经人工审核后仅能进入 immutable development Case，不能污染 held-out。下一步是自动模型/业务 Grader 回填、Trace 自动聚类归因、真实业务金标和线上反馈验证；任何自动 Driver 仍必须尊重宿主审批，不能由经验模块绕过。

## 反馈、实验与用户价值（目标）

保留用户在何处修改/否决结果、修改范围与可选理由，用于失败归因和候选生成。当前任务适应、项目维护、跨任务学习采用不同生效范围。开发反馈与 held-out 分离；反复查看测试集后选版本会泄漏选择信号，需要独立最终验收。

比较质量、人工修正与接管时间、重复解释/重做、恢复成功率、时延和总费用。总费用计入候选生成、后台整理、编译、评测及运行维护；不把少调用几次模型直接宣传成净收益。按验收条件选择最小验证配置，不要求简单任务承担全部评测流程。

关联：[Workflow/Signoff](workflow-signoff.md) · [Agent IR](agent-ir.md) · [Capability Kit](capability-kit.md) · [上下文与记忆](context-memory.md) · [产品架构](../../product/architecture.zh-CN.md)
