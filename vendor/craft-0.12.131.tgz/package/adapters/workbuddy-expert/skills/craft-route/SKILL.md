---
name: craft-route
display_name: Craft 路由
display_name_en: Craft Route
description: Route substantial work to Craft's smallest safe MCP surface before selecting detailed tools.
description_zh: 先用最小 Craft 路由面决定复杂工作，再按需加载能力。
description_en: Route substantial work through Craft before loading detailed capabilities.
category: productivity
version: 0.12.118
author: wdx9413
---

# Craft Route

短回答、简单改写和一次性读取直接完成。会改变交付、外部效果或验收条件的歧义，先写出简短工作约定，并最多提出三个会改变决策的问题；不依赖其他 Skill。

已知工作使用 `craft_default_route_resume`；自然语言续接只在唯一匹配时使用 `craft_default_route_find`；其他复杂工作只调用一次 `craft_default_route`。对所有受治理目标先调用 `craft_intent_compile`，有澄清问题先解决，再调用 `craft_acceptance_compile` 固定完成条件；这套合同适用于研发、销售、内容和其他领域。严格执行返回的下一安全动作，只读取被选中的能力上下文，并用 `craft_task_checkpoint` 记录真实进展。

此专家默认连接 syscall MCP，用于路由、证据、续接和已签发访问票据。完整 MCP 仅供用户明确批准的来源/连接器管理，不能用它扩大权限。
